<?php
// index.php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Welcome to CannaCura!</h1>
    
    <?php if (isset($_SESSION['username'])): ?>
        <p>Hello, <?php echo htmlspecialchars($_SESSION['username']); ?>!</p>
        <p><a href="questions.php">Answer Questions</a></p>
        <p><a href="profile.php">View Profile</a></p>
        <p><a href="logout.php">Logout</a></p>
    <?php else: ?>
        <p><a href="register.php">Register</a></p>
        <p><a href="login.php">Login</a></p>
    <?php endif; ?>
</body>
</html>
