<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="css/styles.css">
</head>

<?php
// logout.php
session_start();
session_unset();
session_destroy();
header("Location: login.php");
?>
