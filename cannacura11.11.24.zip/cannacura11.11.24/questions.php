<?php
// questions.php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Load questions from questions.json
$questions_data = file_get_contents(__DIR__ . '/data/questions.json');
$questions_array = json_decode($questions_data, true);
$questions = $questions_array['questions'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $responses = [];

    foreach ($questions as $index => $question) {
        $question_key = "question_" . $index; // Use question index as the form key
        if (isset($_POST[$question_key])) {
            $responses[$index] = (int) $_POST[$question_key]; // Store answer as option index
        }
    }

    save_responses($_SESSION['username'], $responses);
    echo "Responses recorded. <a href='profile.php'>View your profile</a>";
    exit;
}
?>

<form method="POST">
    <h2>Answer Questions</h2>
    <?php
    foreach ($questions as $index => $question) {
        echo "<p>" . htmlspecialchars($question['question']) . "</p>";
        foreach ($question['options'] as $option_index => $option) {
            // Use question index as key and option index as value
            echo "<label><input type='radio' name='question_$index' value='$option_index' required> $option</label><br>";
        }
    }
    ?>
    <input type="submit" value="Submit Answers">
</form>

<a href="index.php">Home</a><br>
<a href="logout.php">Logout</a>