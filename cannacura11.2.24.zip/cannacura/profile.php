<?php
// profile.php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Load responses and questions
$responses = get_user_responses($_SESSION['username']);
$questions_data = file_get_contents(__DIR__ . '/data/questions.json');
$questions_array = json_decode($questions_data, true);
$questions = $questions_array['questions'];

?>

<?php
// Load JSON data
$data = json_decode(file_get_contents('data/responses.json'), true);

// Specify the user and retrieve their responses
$user = ($_SESSION['username']); 
$responses = isset($data[$user]) ? $data[$user] : null;

if ($responses) {
    // Calculate X-axis (Recreational to Productive) and Y-axis (Relaxed to Alert) averages
    $xAxis = array_sum(array_slice($responses, 0, 5)) / 5;  // Average of first 5 responses
    $yAxis = array_sum(array_slice($responses, 5, 5)) / 5;  // Average of last 5 responses
} else {
    // Default values if user data is missing
    $xAxis = 0;
    $yAxis = 0;
}
?>

<h2>Your Responses</h2>
<ul>
    <?php
    foreach ($responses as $index => $answer_index) {
        $question = $questions[$index]['question'];
        $answer = $questions[$index]['options'][$answer_index];
        echo "<li><strong>$question</strong>: $answer</li>";
    }
    ?>
</ul>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="css/styles.css"> <!-- Link to your CSS file in the css folder -->
</head>
<body>
    <br>
    <h2>Your Chart</h2>
    <div class="chart-container">
        <div class="chart">
            <div class="dot" id="userDot"></div>
            <div class="axis-label x-label">Recreational</div>
            <div class="axis-label x-label x-right">Productive</div>
            <div class="axis-label y-label">Relaxed</div>
            <div class="axis-label y-label y-top">Alert</div>
        </div>
    </div>

    <!-- JavaScript: Pass PHP data to JavaScript -->
    <script>
        // Get PHP values and scale to 0-100 for chart plotting
        const xAxis = <?php echo ($xAxis / 5) * 100; ?>;  // Scale to 0-100 range
        const yAxis = <?php echo ($yAxis / 5) * 100; ?>;

        function plotUserDot() {
            const dot = document.getElementById("userDot");
            const chart = document.querySelector(".chart");

            // Calculate X and Y positions based on scaled user data
            const xPos = (xAxis / 100) * chart.clientWidth;
            const yPos = chart.clientHeight - (yAxis / 100) * chart.clientHeight;

            // Set the dot's position
            dot.style.left = `${xPos}px`;
            dot.style.top = `${yPos}px`;
        }

        plotUserDot();
    </script>
</body>
</html>

<a href="index.php">Home</a><br>
<a href="logout.php">Logout</a>
