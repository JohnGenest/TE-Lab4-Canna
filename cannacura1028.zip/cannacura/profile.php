<?php
// profile.php
session_start();
include 'db.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Load responses and questions
$responses = get_user_responses($_SESSION['username']);
$questions_data = file_get_contents(__DIR__ . '/data/questions.json');
$questions_array = json_decode($questions_data, true);
$questions = $questions_array['questions'];

?>

<h2>Your Responses</h2>
<ul>
    <?php
    foreach ($responses as $index => $answer_index) {
        $question = $questions[$index]['question'];
        $answer = $questions[$index]['options'][$answer_index];
        echo "<li><strong>$question</strong>: $answer</li>";
    }
    ?>
</ul>

<a href="index.php">Home</a><br>
<a href="logout.php">Logout</a>
